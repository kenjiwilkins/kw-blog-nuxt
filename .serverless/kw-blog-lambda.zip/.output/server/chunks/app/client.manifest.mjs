const client_manifest = {
  "_api.t0CsCi0o.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "api.t0CsCi0o.js"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "dynamicImports": [],
    "file": "entry.UgZ8EkSM.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "pages/article/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.Ovh5Zfk4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_api.t0CsCi0o.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/article/[id].vue"
  },
  "pages/category/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.J5ZF82Pv.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/category/[id].vue"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.EzR48eqf.js",
    "imports": [
      "_api.t0CsCi0o.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
