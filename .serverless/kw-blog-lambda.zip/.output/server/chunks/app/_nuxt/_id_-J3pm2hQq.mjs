import { _ as __nuxt_component_0$1 } from '../server.mjs';
import { defineComponent, ref, computed, withCtx, createTextVNode, toDisplayString, unref, useSSRContext, h } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import { useRoute } from 'vue-router';
import '../../nitro/aws-lambda.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import '@unhead/shared';

const defaultFontStyle = {
  "font-family": `ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, "Apple Color Emoji", Arial, sans-serif, "Segoe UI Emoji", "Segoe UI Symbol"`,
  "caret-color": "rgb(55, 53, 47)"
};
function handleAnnotationStyles(annotation) {
  const styles = {
    ...defaultFontStyle
  };
  if (annotation.bold) {
    styles["font-weight"] = "bold";
  }
  if (annotation.italic) {
    styles["font-style"] = "italic";
  }
  if (annotation.underline) {
    styles["text-decoration"] = "underline";
  }
  if (annotation.strikethrough) {
    styles["text-decoration"] = "line-through";
  }
  if (annotation.code) {
    styles["font-family"] = "monospace";
  }
  if (annotation.color) {
    styles["color"] = annotation.color;
  }
  return styles;
}
const IBLOCKS = {
  heading_1: "heading_1",
  heading_2: "heading_2",
  heading_3: "heading_3",
  paragraph: "paragraph",
  bulleted_list_item: "bulleted_list_item",
  numbered_list_item: "numbered_list_item",
  to_do: "to_do",
  divider: "divider"
};
const defaultBlockRenderers = {
  [IBLOCKS.heading_1]: (block, next) => {
    return h(
      "h1",
      {
        style: {
          "font-size": "1.875em"
        }
      },
      next
    );
  },
  [IBLOCKS.heading_2]: (block, next) => {
    return h(
      "h2",
      {
        style: {
          "font-size": "1.5em"
        }
      },
      next
    );
  },
  [IBLOCKS.heading_3]: (block, next) => {
    return h(
      "h3",
      {
        style: {
          "font-size": "1.25em"
        }
      },
      next
    );
  },
  [IBLOCKS.paragraph]: (block, next) => {
    return h(
      "p",
      {
        style: {
          "font-size": "1em",
          "word-wrap": "break-word",
          "white-space": "pre-wrap"
        }
      },
      next
    );
  },
  [IBLOCKS.bulleted_list_item]: (block, next) => {
    const childeLi = h("li", { style: { padding: "0.25em  0" } }, next);
    return h(
      "ul",
      {
        style: {}
      },
      childeLi
    );
  },
  [IBLOCKS.numbered_list_item]: (block, next) => {
    const childeLi = h("li", { style: { padding: "0.25em  0" } }, next);
    return h(
      "ol",
      {
        style: {}
      },
      childeLi
    );
  },
  [IBLOCKS.to_do]: (block, next) => {
    var _a, _b, _c, _d, _e;
    const checkBox = h("input", {
      type: "checkbox",
      style: {
        boxSizing: "border-box",
        height: "16px",
        width: "16px",
        border: ((_a = block.to_do) == null ? void 0 : _a.checked) ? "none" : "1px solid black",
        backgroundColor: ((_b = block.to_do) == null ? void 0 : _b.checked) ? "rgb(35, 131, 226)" : "white"
      },
      checked: (_c = block.to_do) == null ? void 0 : _c.checked
    });
    const checkBoxTextStyle = {
      textDecoration: ((_d = block.to_do) == null ? void 0 : _d.checked) ? "line-through rgba(55, 53, 47, 0.25)" : "none",
      color: ((_e = block.to_do) == null ? void 0 : _e.checked) ? "rgba(55, 53, 47, 0.65)" : "inherit"
    };
    const checkBoxTextArea = h(
      "div",
      { style: { ...checkBoxTextStyle, padding: "0.25em  0" } },
      next
    );
    return h(
      "div",
      {
        style: {
          display: "flex",
          gap: "0.5em",
          alignItems: "center"
        }
      },
      [checkBox, checkBoxTextArea]
    );
  },
  [IBLOCKS.divider]: (block, next) => {
    return h("hr", {
      style: { width: "100%", color: "rgba(55, 53, 47, 0.16)" }
    });
  },
  text: (richTextArray, annotationRenderer) => {
    if (!richTextArray.length) {
      return null;
    }
    const result = richTextArray.map((richText, i) => {
      h(
        "span",
        {
          style: handleAnnotationStyles(richText.annotations)
        },
        richText.text.content
      );
    });
    return h("span", {}, result);
  }
};
function defaultRichTextRenderer(richTextArray) {
  if (!richTextArray || !richTextArray.length) {
    return null;
  }
  const result = richTextArray.map((richText, i) => {
    const attributes = {
      style: handleAnnotationStyles(richText.annotations)
    };
    if (richText.text.link)
      attributes["href"] = richText.href;
    if (i < richTextArray.length - 1)
      attributes["style"]["margin-right"] = "4px";
    return h(
      richText.text.link ? "a" : "span",
      attributes,
      richText.text.content
    );
  });
  return h("span", {}, result);
}
function renderBlocks(blocks, renderer) {
  return blocks.map((block, i) => {
    return renderBlock(block, renderer);
  });
}
function renderBlock(block, renderer) {
  const blockRenderer = renderer;
  if (!blockRenderer[block.type]) {
    console.warn(
      `[notion-vue-renderer] Unsupported block type "${block.type}". Please create an issue if you'd like to see it supported`
    );
    return null;
  }
  return blockRenderer[block.type](
    block,
    defaultRichTextRenderer(block[block.type].rich_text)
  );
}
function removeNulls(array) {
  return array.filter((item) => item !== null);
}
const RichTexts = ({ blocks }) => {
  if (!blocks) {
    return console.warn("[notion-vue-renderer] No blocks provided");
  }
  const results = renderBlocks(blocks, defaultBlockRenderers);
  return removeNulls(results);
};
RichTexts.props = ["blocks"];
const BlocksRenderer = RichTexts;
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "[id]",
  __ssrInlineRender: true,
  setup(__props) {
    useRoute().params.id;
    const properties = ref();
    const body = ref();
    computed(() => {
      return properties.value && body.value;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      if (!properties.value) {
        _push(`<div${ssrRenderAttrs(_attrs)}></div>`);
      } else {
        _push(`<div${ssrRenderAttrs(_attrs)}><h1 class="text-3xl font-semibold">${ssrInterpolate(properties.value.title.title[0].plain_text)}</h1><div class="flex gap-2"><span> category: `);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/category/${properties.value.category.relation[0].id}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(properties.value.categoryName.rollup.array[0].title[0].plain_text)}`);
            } else {
              return [
                createTextVNode(toDisplayString(properties.value.categoryName.rollup.array[0].title[0].plain_text), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</span><span> date: ${ssrInterpolate(properties.value.datePublished.date.start)}</span></div><div class="py-4">`);
        _push(ssrRenderComponent(unref(BlocksRenderer), {
          blocks: body.value,
          class: "py-4"
        }, null, _parent));
        _push(`</div></div>`);
      }
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/article/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_id_-J3pm2hQq.mjs.map
