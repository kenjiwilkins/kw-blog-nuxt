import { useSSRContext, defineComponent, ref, mergeProps, withCtx, createVNode, toDisplayString, openBlock, createBlock } from 'vue';
import { ssrRenderAttrs, ssrRenderList, ssrRenderComponent, ssrRenderClass, ssrInterpolate } from 'vue/server-renderer';
import { _ as __nuxt_component_0$1 } from '../server.mjs';
import '../../nitro/aws-lambda.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import '@unhead/shared';
import 'vue-router';

const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "ArticleList",
  __ssrInlineRender: true,
  props: {
    article: {},
    index: {}
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(ssrRenderComponent(_component_NuxtLink, mergeProps({
        to: `/article/${_ctx.article.id}`
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="${ssrRenderClass([_ctx.index !== 0 ? "mt-2" : "", "flex flex-col p-4 border border-kw-gray-200 rounded-2xl"])}"${_scopeId}><h2 class="text-2xl font-bold"${_scopeId}>${ssrInterpolate(_ctx.article.properties.title.title[0].plain_text)}</h2><div class="flex gap-2"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_NuxtLink, {
              to: `/category/${_ctx.article.properties.category.relation[0].id}`
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<span${_scopeId2}> category: ${ssrInterpolate(_ctx.article.properties.categoryName.rollup.array[0].title[0].plain_text)}</span>`);
                } else {
                  return [
                    createVNode("span", null, " category: " + toDisplayString(_ctx.article.properties.categoryName.rollup.array[0].title[0].plain_text), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<span${_scopeId}> date: ${ssrInterpolate(_ctx.article.properties.datePublished.date.start || "")}</span></div></div>`);
          } else {
            return [
              (openBlock(), createBlock("div", {
                class: ["flex flex-col p-4 border border-kw-gray-200 rounded-2xl", _ctx.index !== 0 ? "mt-2" : ""],
                key: _ctx.article.id
              }, [
                createVNode("h2", { class: "text-2xl font-bold" }, toDisplayString(_ctx.article.properties.title.title[0].plain_text), 1),
                createVNode("div", { class: "flex gap-2" }, [
                  createVNode(_component_NuxtLink, {
                    to: `/category/${_ctx.article.properties.category.relation[0].id}`
                  }, {
                    default: withCtx(() => [
                      createVNode("span", null, " category: " + toDisplayString(_ctx.article.properties.categoryName.rollup.array[0].title[0].plain_text), 1)
                    ]),
                    _: 1
                  }, 8, ["to"]),
                  createVNode("span", null, " date: " + toDisplayString(_ctx.article.properties.datePublished.date.start || ""), 1)
                ])
              ], 2))
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ArticleList.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const blogs = ref([]);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><!--[-->`);
      ssrRenderList(blogs.value, (blog, index) => {
        _push(ssrRenderComponent(_sfc_main$1, {
          article: blog,
          index
        }, null, _parent));
      });
      _push(`<!--]--></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-P5A_mqNs.mjs.map
