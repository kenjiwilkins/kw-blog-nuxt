const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles.Hm41zBhn.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
